# Text to robot training
## A build plan for the first working prototype

October 10, 2026 · Design phase · Not yet a trained robot or live service

### The product

Type what a robot should learn, inspect the proposed task, run training, watch the result, and download a policy with everything needed to reproduce it.

The first version should do one small task end to end. It should not claim that connecting any robot makes it trainable. Connecting an LLM to ROS is already possible; creating a correct learning problem and safely transferring its policy to hardware are separate problems.

**Recommended starting point:** a local-first, open-source training workbench. Build a real CPU training loop first, plus an optional Isaac Sim / Isaac Lab adapter for your own compatible GPU. A hosted simulation service comes later, after compute and licensing are settled.

## 1. The demo that proves the loop

First prompt:

> "Train a two-joint arm to reach a target on the table. Vary the target position and report how often it reaches it."

Use a small, original two-joint arm asset with known geometry, joint limits and actuator settings. No purchased assets or physical robot needed.

The app should:

1. Turn the prompt into a typed task specification, limited to the supported `arm_reach` template.
2. Show the robot, target range, reward terms, stop conditions and training budget for review.
3. Generate the scene from that specification. MuJoCo XML for the CPU path; USD plus Isaac Lab configuration for the optional Isaac path.
4. Run actual PPO training, writing checkpoints and metrics.
5. Evaluate on held-out target positions and seeds using a success test separate from the training reward.
6. Show a replay and export a policy bundle.

A concrete proposed acceptance test: at least 90% success over 100 held-out episodes, reaching within 3 cm of the target before the episode timeout, without violating configured joint limits. These are engineering targets, not measured results. Adjust them only through a recorded task-spec revision.

Compare against an untrained policy and repeat across three training seeds. Report median success, range, duration and hardware. A graph of reward alone is not proof that the task works.

### Keep the two milestones honest

- **CPU milestone:** text -> MuJoCo scene -> real training -> evaluation -> downloadable bundle. This proves the application loop, not Isaac integration or sim-to-real.
- **Isaac milestone:** the same supported task specification -> Isaac scene/task -> actual Isaac Lab training -> replay in Isaac -> export. Mark it untested until run on compatible hardware.

A simpler cart-pole task can smoke-test the trainer before the arm demo. It is not the flagship robotics demonstration.

## 2. What already exists

### ROS MCP servers: reuse the bridge, not an unrestricted robot console

`robotmcp/ros-mcp-server` exposes robot observation and control through ROS and rosbridge, including topics, services and actions. Its README includes a simulated Unitree Go2 example. Apache-2.0. [1]

`hieutachi/rosbridge-mcp` is a smaller MIT-licensed candidate with an explicit read-only mode and a read-service allowlist. Its default read-only setting is false, so our integration must force read-only rather than trust the default. The project is early-stage and its test/safety claims are maintainer claims, not our audit. [2]

Recommendation: start with read-only robot discovery and telemetry. Later wrap selected capabilities in our own robot-specific safety checks. Neither project proves that arbitrary hardware is safe to control.

### Robot Context Protocol: a real proposal, not a universal robot driver

The RCP paper describes a runtime-agnostic interface with read, write, execute and subscribe operations over web transports, with adapters to robot runtimes. It is a useful design reference. The paper does not establish broad standard adoption, universal vendor compatibility or a safety certification. [3]

Keep our internal robot capability manifest transport-neutral. Use ROS 2 / rosbridge initially; add an RCP adapter only when a particular implementation and robot require it. Do not create a new protocol just to get the demo working.

### Isaac Lab: the training backbone for the Isaac branch

Isaac Lab is an open-source robotics learning framework with RL and other workflows. Its framework is BSD-3-Clause, with dependencies and assets under other terms. The current `develop` docs also describe a Newton backend without full Isaac Sim. That is worth evaluating later, not a substitute for a tested, pinned release. [4, 5]

Use an existing task structure and PPO implementation. Generate validated task parameters, not a whole simulator or training algorithm from text.

### Eureka and Text2Reward: useful reward-design research

Eureka uses LLM-generated reward code plus iterative training feedback. Its official implementation uses OpenAI API queries and an older Isaac Gym-based stack. MIT code does not mean its default workflow is free to run. [6]

Text2Reward generates executable dense reward programs grounded in an environment abstraction, with user feedback to refine them. Its older dependency stack is another reason to borrow the method before adopting the repository wholesale. [7]

For v1, choose from tested reward terms: distance to target, action smoothness and limit penalties. Arbitrary reward-code generation is a later sandboxed experiment. LLM-generated code must never run with host credentials or hardware access.

### Text-to-scene projects: real leads, too heavy for the first loop

`artiscene` generates simulation-ready USD scenes for Isaac using articulated objects and deterministic USD authoring. Apache-2.0; the default setup needs an OpenAI API key and asset catalog. Its reported benchmark and cost are project claims, not measurements we reproduced. [8]

SceneSmith generates interactive scenes with estimated physical properties. MIT code, but additional datasets, model access, GPU memory and API dependencies matter. Its README describes 24 GB and 32 GB generation-backend requirements and OpenAI keys. [9]

These are research references for later open-ended worlds. Start with original primitives and a small checked asset catalog. A visually convincing scene is not necessarily a correct training environment.

## 3. Architecture

### Message and job flow

Text input -> task compiler -> schema validation -> task preview -> immutable job specification -> local worker -> evaluation -> policy bundle.

The task compiler can use a local language model later. The first reproducible, no-key demo can use a constrained parser and clearly label it as such. Do not call a keyword parser a general LLM planner. Unsupported tasks should explain what is supported or ask for a missing parameter, never silently substitute another goal.

### Proposed stack

- **UI:** small TypeScript web interface for task review, run status, metrics and downloads.
- **API:** Python/FastAPI, so simulation and training adapters stay in the same language.
- **Schemas:** Pydantic models for robot, scene, task, training budget, evaluation and artifacts.
- **Storage:** SQLite for job records; local run directories for checkpoints and bundles.
- **CPU backend:** MuJoCo plus a Gymnasium-compatible environment and PPO through Stable-Baselines3. MuJoCo is Apache-2.0; the SB3 Zoo is an MIT-licensed training/evaluation reference. [10, 11]
- **Isaac backend:** optional separately installed Isaac Sim / Isaac Lab; exact compatible versions pinned after hardware testing.
- **Robot bridge:** separate ROS 2 adapter, initially disabled for writes.
- **LLM adapter:** optional and provider-neutral. No paid API call without approval; no secret, private repository or live sensor upload by default.

These are implementation choices, not claims that the full stack has already been tested together.

### Versioned task contract

Each specification records:

- robot asset ID, asset hash, joints, units, limits and actuator model;
- allowed scene template and bounded object coordinates;
- observation and action definitions, normalization and control cadence;
- task goal, reward terms, success condition and termination rules;
- simulation timestep, randomization ranges and seeds;
- trainer settings, maximum steps, wall-time cap and checkpoint interval;
- backend and dependency versions.

Training state: queued -> validating -> running -> evaluating -> succeeded / failed / cancelled. Use durable job IDs, heartbeats and restartable checkpoints. An accepted job is not a completed job. A stopped worker must not leave the UI saying "training" forever.

### Worker boundary

Do not run RL inside a web request. The local worker owns long jobs and resources; the UI watches status. On a future remote deployment, workers pull authenticated jobs and upload artifacts. Never expose a GPU worker's shell or ROS port directly to the public internet.

The trainer gets bounded task data, not a free-form shell command. Worker processes run with time, memory and disk limits, no account credentials, restricted network access, and no physical-robot route. Keep cancellation separate from physical emergency stop.

## 4. The download is more than a model file

Export a ZIP containing:

- inference model in a verified format, plus training checkpoint for resume;
- robot and task manifests;
- observation/action schema, joint order, units, scaling and normalization;
- simulation timestep, control cadence, actuator settings and limits;
- evaluation results, training metrics, seed and dependency lock;
- checksums, asset attribution/license notes and a model card;
- a replay/inference command and explicit supported hardware/backend list.

For the Isaac path, the current deployment docs distinguish exported TorchScript/ONNX models from raw training checkpoints and require configuration plus ordered IO descriptors. Preserve that deployment contract instead of shipping a bare `.pt` file. Supported exporters vary by pinned version and RL library. [12]

Never load a stranger's pickle/checkpoint in the API process. Treat uploaded models as code-capable files, verify provenance and inspect them in an isolated worker.

## 5. Compute: what $0 can actually buy

### Your computer: preferred Isaac route

The current Isaac Sim requirements list 32 GB RAM, an RTX 4080-class GPU and 16 GB VRAM as the minimum reference configuration, and say GPUs without RT cores such as A100/H100 are unsupported. Isaac Lab training can require more memory. Compatibility must be checked against the exact release. [13]

The target workstation specifications must be checked before running this backend. Until then, do not promise an Isaac training runtime or throughput. With no compatible RTX machine, proceed with the real CPU demo and leave Isaac execution explicitly pending.

### Colab free: interactive experiments only

Colab does not guarantee GPU type, availability or runtime. Its FAQ lists restrictions on free remote-control and primarily web-UI use; it is not the backend for an unattended public training service. Use manually run notebooks for compatible experiments, checkpoint early and export results before the session ends. [14]

An unofficial Isaac-on-Colab repository exists, but calls its setup demo-only, unsupported, and unsuitable for serious development. It documents older Isaac versions. That is evidence of an experiment, not a production compute strategy. [15]

### Kaggle: useful batch experiments, not a promised Isaac host

Kaggle documents limited free GPU availability, P100/T4 notebook configurations, session limits and saved-output storage. Actual account quota and assigned accelerator still need checking; this design does not promise a fixed number of weekly GPU hours. The documented accelerators do not establish a supported current Isaac Sim setup. [16]

Good candidate for compatible open-source training experiments and saved checkpoints. Never keep sessions alive artificially or rotate accounts to evade limits.

### Hosted UI versus training service

The first version runs locally, with no hosting account or credit card required. A static project demo can be hosted separately later; it must not pretend that a browser tab supplies the GPU. Paid GPU workers, storage or enterprise licenses are outside the $0 grant.

## 6. Licensing changes the company plan

Isaac Sim's source is Apache-2.0, but running it needs separately licensed NVIDIA components and assets. The current NVIDIA FAQ says internal R&D is free, while redistribution with Omniverse Kit or delivering it as a service to third parties requires NVIDIA AI Enterprise licensing. Selling only simulation outputs or custom code/USD assets is treated differently. [17]

Therefore:

- Publish our own open-source orchestration, task templates, tests and original assets.
- Do not bundle NVIDIA runtime binaries or restricted assets into the repository.
- Keep Isaac as an optional user-installed adapter for the internal prototype.
- Use a fully open-source simulation backend for a strict open-source-only product path.
- Resolve service-delivery licensing before a public Isaac-powered training service. Do not assume that "bring your own GPU" settles every licensing question.

This is a technical scope recommendation, not legal clearance for a business model.

## 7. Physical robots: a later, separate acceptance gate

A USB cable or ROS connection does not tell us the robot's dynamics, calibration, joint order, controller behavior or safety limits. A policy for one robot cannot be assumed to fit another.

Progression:

1. Read-only discovery: identity, joint names, telemetry and driver capabilities.
2. Digital twin: checked asset, calibration, actuator model and latency.
3. Simulation validation across payload, friction, sensor noise and delay ranges.
4. Shadow mode: infer actions from telemetry without executing them.
5. A supervised, low-energy test only after robot-specific review and explicit permission.

The local safety controller, not the LLM, enforces velocity/torque/workspace limits, stale-command timeouts, watchdogs and stop behavior. Require an independent physical emergency stop and a trained operator. No human-adjacent trial, autonomous torque stream or bypass of manufacturer protections.

The LLM chooses approved high-level skills. A tested controller runs the real-time loop. MCP or RCP supplies an interface; neither is a functional-safety layer.

## 8. Phased roadmap

### Phase A: a reproducible software loop

Schema, constrained text compiler, scene preview, local job runner, CPU arm-reach training, evaluation, export and tests. Document limitations in the README. No fake training progress.

**Exit:** fresh install -> real run -> reload downloaded policy -> repeat evaluation.

### Phase B: the Isaac proof

Check your hardware; pin one compatible release pair; add generated USD/task config; run the same task in Isaac Lab; replay and export. Compare interfaces, not assume that MuJoCo and Isaac checkpoints are interchangeable.

**Exit:** evidence of an actual Isaac training run, tested export and replay, with hardware and versions recorded.

### Phase C: useful language and iteration

Optional local LLM producing the same validated schema; additional approved task templates; bounded reward search; failure summaries; task revisions; resumable jobs. Start with one extra task, not arbitrary humanoid locomotion.

**Exit:** unsupported prompts fail clearly; supported variations stay within limits; evaluation catches reward hacking.

### Phase D: one robot, supervised

Pick one exact robot and driver; integrate read-only bridge; validate its twin; then shadow mode and a separately approved physical trial.

**Exit:** robot-specific safety and deployment checklist, observed test results and rollback/stop route.

### Phase E: service product

Multi-user isolation, quotas, artifact retention, worker enrollment, billing model and license review. Demand reliable training runs before scaling a polished UI.

**Exit:** a reviewed compute/licensing plan and measured cost per successful training job. No free-cloud promise at this stage.

## 9. Repository and proof discipline

Working name: `robot-training-workbench` (proposed, not yet created).

Suggested layout: `apps/web`, `packages/spec`, `worker`, `backends/mujoco`, `backends/isaac`, `bridges/ros2`, `assets/original`, `tests`, `docs` and `examples`.

Use feature branches and checks. Do not modify unrelated repositories. Keep credentials, personal messages, private projects, downloaded vendor binaries and robot logs out of git. Document dependency and asset licenses separately from our own code license.

The README should state exactly which stage works: design, CPU-trained, Isaac-tested, or hardware-tested. Every release links to its run manifest and results. A placeholder adapter is not an integration.

## 10. Decisions you need to make

Only the first two block the next hardware-dependent milestone. Software work can start now.

1. What computer will run training? GPU model and VRAM, RAM, OS and free storage.
2. Which exact robot should be the first physical target, and do you already have it and its driver/model files?
3. Is a fully open-source core plus optional separately installed Isaac adapter acceptable? A strictly open-source runnable stack cannot depend on the full Isaac runtime.
4. Should the new GitHub repository be public or private? The prototype can be prepared without deciding this today.

No physical motion or paid compute is approved by this design.

## Source notes

All pages below were fetched for this design on October 10, 2026. Official documentation establishes current published requirements/policies; repository READMEs and papers establish what authors describe, not what this prototype has reproduced. Moving `latest`, `main` and `develop` URLs must be replaced by pinned versions during implementation.

[1] ROS MCP project and Apache-2.0 license: https://github.com/robotmcp/ros-mcp-server

[2] ROS bridge candidate and read-only behavior: https://github.com/hieutachi/rosbridge-mcp

[3] RCP research paper: https://arxiv.org/html/2506.11650v1

[4] Isaac Lab repository and dependency caveats: https://github.com/isaac-sim/IsaacLab/blob/main/README.md

[5] Isaac Lab development installation/backend documentation: https://isaac-sim.github.io/IsaacLab/develop/source/setup/installation/index.html

[6] Eureka research implementation: https://github.com/eureka-research/Eureka/

[7] Text2Reward research implementation: https://github.com/xlang-ai/text2reward

[8] artiscene text-to-USD project: https://github.com/JunjianChi/artiscene

[9] SceneSmith scene-generation project: https://github.com/nepfaff/scenesmith/blob/main/README.md

[10] MuJoCo simulator and license: https://github.com/google-deepmind/mujoco/

[11] SB3 training/evaluation reference: https://github.com/DLR-RM/rl-baselines3-zoo

[12] Isaac policy packaging/deployment contract: https://docs.isaacsim.omniverse.nvidia.com/latest/isaac_lab_tutorials/tutorial_policy_deployment.html

[13] Isaac Sim hardware requirements: https://docs.isaacsim.omniverse.nvidia.com/latest/installation/requirements.html

[14] Colab official limits and acceptable-use guidance: https://research.google.com/colaboratory/intl/en-GB/faq.html

[15] Unofficial, demo-only Colab instructions: https://github.com/j3soon/isaac-sim-colab

[16] Kaggle notebook documentation: https://www.kaggle.com/docs/notebooks

[17] NVIDIA licensing FAQ, including service-delivery gate: https://docs.isaacsim.omniverse.nvidia.com/latest/common/license-faq.html
