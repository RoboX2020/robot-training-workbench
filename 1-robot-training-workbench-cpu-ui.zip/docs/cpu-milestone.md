# CPU milestone evidence

October 10, 2026. This is a working command-line scaffold, not the finished application.

- Real MuJoCo simulation and PPO training on CPU.
- 100,096 training steps; about 77 seconds in the current environment.
- Held-out 100-episode success: 12%, versus 0% untrained.
- Mean final distance: 0.270 m, versus 0.434 m untrained.
- Configured limit violations: 0.
- 90% proposed acceptance target: **not met**.
- Single training seed only; no robustness or hardware claim.

The control task is free-space planar reaching with collision detection disabled. An early joint-unit bug was found through an actuator regression test, fixed by explicitly setting radians, and covered by tests. Earlier failed runs are not evidence for the corrected scene.

Software checks cover schema validation, rejection of unsupported prompt constraints, Gym environment interface, deterministic reset, finite observations, invalid-action rejection, joint-range units, actuator motion and train/export/reload parity. The CLI and bundle work; a local task-review/replay UI is also available. Actual 320px and 900px screenshots were inspected; 390px was tested for overflow. Supported prompt review, unsupported-constraint rejection and replay play/reset were tested. Browser training controls are not available.

Current exact tested dependency versions and measured results are included in the repository. Runtime data and policy files are excluded from git.
