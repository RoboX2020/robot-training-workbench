import hashlib
import json
import platform
import time
import zipfile
from importlib.metadata import version
from pathlib import Path
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from .env import ArmReachEnv, SCENE_XML
from .spec import TaskSpec

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)

def evaluate(model, spec, episodes=100, seed_offset=10000):
    env = ArmReachEnv(spec)
    successes = violations = 0
    distances = []
    for episode in range(episodes):
        observation, _ = env.reset(seed=spec.seed + seed_offset + episode)
        for _ in range(spec.episode_steps):
            action, _ = model.predict(observation, deterministic=True)
            observation, _, terminated, truncated, info = env.step(action)
            if terminated or truncated:
                break
        successes += int(info["is_success"])
        violations += int(info["limit_violation"])
        distances.append(info["distance_m"])
    env.close()
    return {"episodes": episodes, "seed_offset": seed_offset, "success_rate": successes / episodes, "limit_violations": violations, "mean_final_distance_m": float(np.mean(distances))}

def train(spec: TaskSpec, root: Path, evaluation_episodes=100):
    # Fresh run folder required. Never overwrite another policy.
    root.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    write_json(root / "task.json", spec.model_dump())
    (root / "scene.xml").write_text(SCENE_XML)
    write_json(root / "status.json", {"state": "running", "requested_steps": spec.train_steps})
    start = time.monotonic()
    try:
        env = Monitor(ArmReachEnv(spec), str(root / "training"))
        model = PPO("MlpPolicy", env, seed=spec.seed, device="cpu", n_steps=256, batch_size=64, verbose=0)
        baseline = evaluate(model, spec, evaluation_episodes)
        model.learn(total_timesteps=spec.train_steps)
        model.save(root / "policy")
        result = evaluate(model, spec, evaluation_episodes)
        env.close()
        metadata = {"state": "succeeded", "meaning": "training and evaluation completed, not an acceptance or hardware-safety claim", "actual_steps": model.num_timesteps, "duration_seconds": time.monotonic() - start, "baseline": baseline, "evaluation": result, "acceptance_target_met": result["success_rate"] >= 0.9 and result["limit_violations"] == 0, "python": platform.python_version(), "machine": platform.machine(), "versions": {name: version(name) for name in ["mujoco", "gymnasium", "stable-baselines3", "torch", "numpy"]}}
        write_json(root / "results.json", metadata)
        write_json(root / "interface.json", {"observation": ["sin(shoulder)", "sin(elbow)", "cos(shoulder)", "cos(elbow)", "shoulder_velocity_clipped_20_rad_s", "elbow_velocity_clipped_20_rad_s", "target_x_m", "target_y_m", "target_minus_tip_x_m", "target_minus_tip_y_m"], "action": ["shoulder_position_target", "elbow_position_target"], "action_mapping": "clip(qpos + clip(action,-1,1) * 0.15 radians, -3, 3)", "simulation_dt_seconds": 0.01, "control_dt_seconds": 0.05, "physical_robot_supported": False, "format": "SB3 PPO ZIP; trusted local loading only; not ONNX or Isaac policy"})
        (root / "MODEL_CARD.md").write_text("# Simulation-only policy\n\nOriginal planar arm in MuJoCo only. Not a hardware controller. This SB3 ZIP uses pickle-capable serialization: load only artifacts you created and trust. Check results.json for measured performance. No acceptance result is implied by completion.\n")
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file() and p.name != "status.json"}
        write_json(root / "checksums.json", hashes)
        with zipfile.ZipFile(root / "bundle.zip", "w", zipfile.ZIP_DEFLATED) as archive:
            for path in root.iterdir():
                if path.is_file() and path.name not in {"bundle.zip", "status.json"}:
                    archive.write(path, path.name)
        write_json(root / "status.json", metadata)
        return metadata
    except BaseException as error:
        write_json(root / "status.json", {"state": "cancelled" if isinstance(error, KeyboardInterrupt) else "failed", "error_type": type(error).__name__, "error": str(error)})
        raise
