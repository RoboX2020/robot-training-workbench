import gymnasium as gym
import mujoco
import numpy as np
from gymnasium import spaces
from .spec import TaskSpec

# Original primitive asset, SI units, no downloaded robot model.
SCENE_XML = '''<mujoco model="original_two_joint_arm">
 <compiler angle="radian"/><option timestep="0.01" gravity="0 0 -9.81"/>
 <default><joint damping="2" limited="true" range="-3.05 3.05"/><geom density="1000" contype="0" conaffinity="0"/></default>
 <worldbody>
  <geom name="table" type="box" size="0.5 0.5 0.025" pos="0 0 -0.04" rgba="0.8 0.8 0.8 1"/>
  <body name="link1" pos="0 0 0"><joint name="shoulder" axis="0 0 1"/>
   <geom type="capsule" fromto="0 0 0 0.2 0 0" size="0.015" rgba="0.2 0.5 0.8 1"/>
   <body name="link2" pos="0.2 0 0"><joint name="elbow" axis="0 0 1"/>
    <geom type="capsule" fromto="0 0 0 0.2 0 0" size="0.015" rgba="0.2 0.7 0.5 1"/>
    <site name="tip" pos="0.2 0 0" size="0.015"/>
   </body>
  </body>
  <site name="target" pos="0.2 0.2 0" size="0.02" rgba="1 0.2 0.2 1"/>
 </worldbody>
 <actuator><position joint="shoulder" kp="10" ctrlrange="-3 3" ctrllimited="true"/><position joint="elbow" kp="10" ctrlrange="-3 3" ctrllimited="true"/></actuator>
</mujoco>'''

class ArmReachEnv(gym.Env):
    metadata = {"render_modes": []}
    def __init__(self, spec: TaskSpec | None = None):
        self.task_spec = spec or TaskSpec()
        self.model = mujoco.MjModel.from_xml_string(SCENE_XML)
        self.data = mujoco.MjData(self.model)
        self.tip_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, "tip")
        self.target_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, "target")
        self.action_space = spaces.Box(-1, 1, (2,), dtype=np.float32)
        self.observation_space = spaces.Box(-np.inf, np.inf, (10,), dtype=np.float32)
        self.previous_action = np.zeros(2)
        self.target = np.zeros(2)
        self.steps = 0
    def _observation(self):
        return np.concatenate((np.sin(self.data.qpos), np.cos(self.data.qpos), np.clip(self.data.qvel, -20, 20), self.target, self.target - self.data.site_xpos[self.tip_id, :2])).astype(np.float32)
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[:] = self.np_random.uniform(-1, 1, 2)
        radius = self.np_random.uniform(self.task_spec.target_radius_min_m, self.task_spec.target_radius_max_m)
        angle = self.np_random.uniform(-np.pi, np.pi)
        self.target = radius * np.array([np.cos(angle), np.sin(angle)])
        self.model.site_pos[self.target_id, :2] = self.target
        mujoco.mj_forward(self.model, self.data)
        self.steps = 0
        self.previous_action = np.zeros(2)
        return self._observation(), {}
    def step(self, action):
        action = np.asarray(action, dtype=np.float64)
        if action.shape != (2,) or not np.all(np.isfinite(action)):
            raise ValueError("Action must contain two finite values")
        action = np.clip(action, -1, 1)
        self.data.ctrl[:] = np.clip(self.data.qpos + action * 0.15, -3.0, 3.0)
        for _ in range(5):
            mujoco.mj_step(self.model, self.data)
        self.steps += 1
        distance = float(np.linalg.norm(self.data.site_xpos[self.tip_id, :2] - self.target))
        limit_violation = bool(np.any(np.abs(self.data.qpos) > 3.05 + 0.02))
        success = distance <= self.task_spec.success_distance_m and not limit_violation
        reward = -5.0 * distance - 0.005 * float(np.square(action - self.previous_action).sum()) + (1.0 if success else 0.0)
        self.previous_action = action.copy()
        info = {"distance_m": distance, "is_success": success, "limit_violation": limit_violation}
        return self._observation(), reward, success or limit_violation, self.steps >= self.task_spec.episode_steps, info
