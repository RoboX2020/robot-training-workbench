from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

class TaskSpec(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    schema_version: Literal[1] = 1
    task: Literal["arm_reach"] = "arm_reach"
    backend: Literal["mujoco"] = "mujoco"
    seed: int = Field(default=42, ge=0, le=2**31-1)
    train_steps: int = Field(default=2048, ge=256, le=1_000_000)
    episode_steps: int = Field(default=100, ge=20, le=500)
    success_distance_m: float = Field(default=0.03, ge=0.005, le=0.05)
    target_radius_min_m: float = Field(default=0.12, ge=0.1, le=0.2)
    target_radius_max_m: float = Field(default=0.35, ge=0.21, le=0.38)

SUPPORTED_PROMPT = "Train a two-joint arm to reach a target on the table. Vary the target position and report how often it reaches it."

def compile_prompt(prompt: str) -> TaskSpec:
    # Deliberately exact, inspectable demo grammar. Never pretend to understand
    # arbitrary instructions or discard unsupported constraints.
    normalized = " ".join(prompt.lower().strip().split()).rstrip(".")
    accepted = {" ".join(SUPPORTED_PROMPT.lower().split()).rstrip("."), "train a two-joint arm to reach a target", "arm_reach"}
    if normalized not in accepted:
        raise ValueError("Unsupported prompt. This constrained parser supports only the documented two-joint arm reach demo. Use arm_reach or the example prompt; explicit settings belong in the task JSON.")
    return TaskSpec()
