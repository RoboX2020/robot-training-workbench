from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ConfigDict
from .spec import compile_prompt

app = FastAPI(title="Local simulation-only task review")
class Prompt(BaseModel):
    model_config = ConfigDict(extra="forbid")
    prompt: str = Field(min_length=1, max_length=2000)

@app.post("/api/compile")
def compile_task(body: Prompt):
    try:
        return compile_prompt(body.prompt).model_dump()
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error))

# Development review only; no model upload, job start or robot route.
web = Path(__file__).resolve().parents[2] / "web"
app.mount("/", StaticFiles(directory=web, html=True), name="web")
