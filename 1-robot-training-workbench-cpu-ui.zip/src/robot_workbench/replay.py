"""Headless original-scene replay through MuJoCo, no hardware route."""
import json
from pathlib import Path
import mujoco
from stable_baselines3 import PPO
from .env import ArmReachEnv
from .spec import TaskSpec

def replay(run: Path, output: Path, seed: int = 10042):
    # Only call for trusted local artifacts. No remote model import.
    spec = TaskSpec.model_validate_json((run / "task.json").read_text())
    model = PPO.load(run / "policy.zip", device="cpu")
    env = ArmReachEnv(spec)
    observation, _ = env.reset(seed=seed)
    frames = []
    for _ in range(spec.episode_steps):
        frames.append({"joints_rad": env.data.qpos.tolist(), "target_m": env.target.tolist(), "tip_m": env.data.site_xpos[env.tip_id, :2].tolist()})
        action, _ = model.predict(observation, deterministic=True)
        observation, _, terminated, truncated, info = env.step(action)
        if terminated or truncated:
            break
    output.write_text(json.dumps({"schema_version": 1, "seed": seed, "control_dt_seconds": 0.05, "link_lengths_m": [0.2, 0.2], "frames": frames, "result": info}, indent=2) + "\n")
    return frames
