"""Independent local robot-learning demo. No physical control integration."""
