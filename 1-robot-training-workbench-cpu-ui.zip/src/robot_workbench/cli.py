import argparse
import json
from pathlib import Path
from stable_baselines3 import PPO
from .spec import TaskSpec, compile_prompt
from .train import train, evaluate

def main():
    parser = argparse.ArgumentParser(description="Constrained, local simulation-only learning demo")
    commands = parser.add_subparsers(dest="command", required=True)
    compile_cmd = commands.add_parser("compile")
    compile_cmd.add_argument("prompt")
    training = commands.add_parser("train")
    training.add_argument("--spec", type=Path, required=True)
    training.add_argument("--output", type=Path, required=True)
    evaluation = commands.add_parser("evaluate")
    evaluation.add_argument("--run", type=Path, required=True)
    evaluation.add_argument("--episodes", type=int, default=100)
    evaluation.add_argument("--trust-local-policy", action="store_true", help="Acknowledge loading your own pickle-capable SB3 artifact")
    args = parser.parse_args()
    if args.command == "compile":
        print(compile_prompt(args.prompt).model_dump_json(indent=2))
    elif args.command == "train":
        print(json.dumps(train(TaskSpec.model_validate_json(args.spec.read_text()), args.output), indent=2))
    else:
        if not args.trust_local_policy:
            parser.error("Policy loading requires --trust-local-policy; never load untrusted model ZIPs")
        if not 1 <= args.episodes <= 10000:
            parser.error("episodes must be 1..10000")
        spec = TaskSpec.model_validate_json((args.run / "task.json").read_text())
        policy = PPO.load(args.run / "policy.zip", device="cpu")
        print(json.dumps(evaluate(policy, spec, args.episodes), indent=2))

if __name__ == "__main__":
    main()
