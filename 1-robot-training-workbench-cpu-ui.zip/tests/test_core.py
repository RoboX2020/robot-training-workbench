import numpy as np
import pytest
from pydantic import ValidationError
from stable_baselines3.common.env_checker import check_env
from robot_workbench.env import ArmReachEnv
from robot_workbench.spec import TaskSpec, compile_prompt, SUPPORTED_PROMPT

@pytest.mark.parametrize("prompt", ["arm_reach", SUPPORTED_PROMPT, "Train a two-joint arm to reach a target"])
def test_supported_prompts(prompt):
    assert compile_prompt(prompt).task == "arm_reach"

@pytest.mark.parametrize("prompt", ["make a humanoid walk", "arm_reach with torque unlimited", "train a two-joint arm to reach a target at 9 meters"])
def test_rejects_unknown_scope(prompt):
    with pytest.raises(ValueError):
        compile_prompt(prompt)

def test_spec_rejects_extra_and_invalid_budget():
    with pytest.raises(ValidationError):
        TaskSpec(train_steps=-1)
    with pytest.raises(ValidationError):
        TaskSpec(robot="physical")

def test_gym_contract():
    check_env(ArmReachEnv())

def test_seed_repeatable():
    env = ArmReachEnv()
    first, _ = env.reset(seed=12)
    second, _ = env.reset(seed=12)
    np.testing.assert_array_equal(first, second)

def test_action_rejects_nan():
    env = ArmReachEnv()
    env.reset(seed=1)
    with pytest.raises(ValueError):
        env.step([float("nan"), 0])

def test_finite_rollout():
    env = ArmReachEnv()
    env.reset(seed=3)
    for _ in range(100):
        obs, reward, term, trunc, info = env.step([0.5, -0.3])
        assert np.all(np.isfinite(obs)) and np.isfinite(reward)
        if term or trunc:
            break

def test_training_export_reload(tmp_path):
    from stable_baselines3 import PPO
    from robot_workbench.train import train, evaluate
    result = train(TaskSpec(train_steps=256), tmp_path / "run", evaluation_episodes=2)
    assert result["state"] == "succeeded"
    assert (tmp_path / "run" / "bundle.zip").exists()
    policy = PPO.load(tmp_path / "run" / "policy.zip", device="cpu")
    evaluated = evaluate(policy, TaskSpec(train_steps=256), episodes=2)
    assert evaluated == result["evaluation"]

def test_actuator_moves_without_spurious_self_contacts():
    env = ArmReachEnv()
    env.reset(seed=5)
    start = env.data.qpos.copy()
    for _ in range(20):
        env.step([1, 1])
    assert env.data.ncon == 0  # This simplified task deliberately has no collision model.
    assert np.all(env.data.qpos > start + 0.3)

def test_joint_limit_units_are_radians():
    env = ArmReachEnv()
    np.testing.assert_allclose(env.model.jnt_range, [[-3.05, 3.05], [-3.05, 3.05]])

def test_review_api():
    from fastapi.testclient import TestClient
    from robot_workbench.api import app
    client = TestClient(app)
    assert client.post('/api/compile', json={'prompt':'arm_reach'}).json()['task'] == 'arm_reach'
    assert client.post('/api/compile', json={'prompt':'arm_reach unlimited torque'}).status_code == 422
    assert client.post('/api/compile', json={'prompt':'arm_reach', 'execute':True}).status_code == 422
    assert client.get('/').status_code == 200
